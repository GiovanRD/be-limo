# BE Véhicule Autonome 2026 — Groupe 1

**Livrable 2 : simulation des fonctions de planification, de contrôle et de détection**

ENSEM — Crystal RIBU, Morgan HOFFMANN, Giovan ROCCA-DURINGER — robot AgileX LIMO n° 201

Ce dépôt part de l'environnement de référence `room207-limo` (simulation de la salle 207). Nos développements se trouvent dans le paquet ROS 2 **`be_limo`** (`ros2_foxy/be_limo/`).

**Démonstration** : la LIMO parcourt une boucle de 17,6 m sur la piste QCar. Elle planifie son itinéraire sur la carte des voies, le suit avec une loi de commande *pure pursuit*, s'arrête au panneau stop, s'arrête devant un obstacle détecté au lidar et attend qu'il soit retiré, et respecte un feu tricolore détecté à la caméra.

---

## Sommaire

1. [Configuration nécessaire](#1-configuration-nécessaire)
2. [Architecture du dépôt et du programme](#2-architecture-du-dépôt-et-du-programme)
3. [Exemple de mise en œuvre](#3-exemple-de-mise-en-œuvre)
4. [Pour aller plus loin](#4-pour-aller-plus-loin)

---

## 1. Configuration nécessaire

### 1.1. Logiciels

| Logiciel | Version | Rôle |
|---|---|---|
| Ubuntu | 20.04 LTS | système de référence du labo |
| ROS 2 | Foxy (`ros-foxy-desktop`) | intergiciel |
| Gazebo | 11 (Gazebo Classic, avec `ros-foxy-gazebo-ros-pkgs`) | simulation |
| Python | 3.8 (celui d'Ubuntu 20.04), avec `numpy` et `opencv` | nœuds du paquet |
| MATLAB | R2020b ou plus récent, sans boîte à outils | version MATLAB de la loi de commande (facultatif) |

**Autre version d'Ubuntu (22.04, 24.04)** : ROS 2 Foxy ne s'installe que sur Ubuntu 20.04. On utilise alors un conteneur Docker Ubuntu 20.04 avec ROS 2 Foxy, dans lequel on monte le workspace :
```bash
xhost +local:docker
docker run -it --name foxy --net=host --device /dev/dri \
  -e DISPLAY=$DISPLAY -v /tmp/.X11-unix:/tmp/.X11-unix \
  -v ~/ros2_ws:/root/ros2_ws osrf/ros:foxy-desktop bash
# dans le conteneur, une seule fois :
apt update && apt install -y ros-foxy-gazebo-ros-pkgs ros-foxy-xacro python3-rosdep python3-colcon-common-extensions
```
Toutes les commandes ROS 2 de ce document se tapent alors dans le conteneur (`docker start -ai foxy`, puis `docker exec -it foxy bash` pour un autre terminal).

### 1.2. Dépôts nécessaires dans le workspace

`be_limo` utilise les dépôts communs `robotic_lab`, installés selon leurs propres README :

| Dépôt | Paquets utilisés par `be_limo` | Pour quoi |
|---|---|---|
| ce dépôt (groupe 1) | `be_limo`, `room207_limo` | nos nœuds ; environnement de la salle 207 |
| `limo` (dossier `ros2_foxy/limo_ros2`) | `limo_car`, `limo_description` | modèle Gazebo de la LIMO, conversion `/cmd_vel` → `/cmd_vel_gazebo` |
| `environment` | `qcar_large_track` | piste QCar et sa texture |
| `teleoperation`, `recording` | — | utilisés par `room207_limo` seulement |

Organisation du workspace :
```text
~/ros2_ws/src/
├── be-2026-group-01/        ce dépôt
│   └── ros2_foxy/
│       ├── be_limo/         nos développements
│       └── room207_limo/    environnement de référence
├── limo/                    (ros2_foxy/limo_ros2 seulement, voir le README de limo)
├── environment/
├── teleoperation/
└── recording/
```

### 1.3. Compilation

```bash
source /opt/ros/foxy/setup.bash
cd ~/ros2_ws
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
source install/setup.bash
```
Vérification :
```bash
ros2 pkg executables be_limo
```
Résultat attendu : `global_planner`, `local_controller`, `localization_node`, `obstacle_detector`, `traffic_light_manager`, `vision_node`.

Dans chaque nouveau terminal : `source /opt/ros/foxy/setup.bash && source ~/ros2_ws/install/setup.bash`.

Aucune autre configuration n'est nécessaire. Le lancement règle lui-même `GAZEBO_MODEL_DATABASE_URI` pour que Gazebo ne cherche pas de modèles sur Internet. Les modèles de la piste sont trouvés grâce au paquet `qcar_large_track`.

---

## 2. Architecture du dépôt et du programme

### 2.1. Organisation du dépôt

```text
be-2026-group-01/
├── README.md                       ce document
├── matlab/                         version MATLAB/Simulink de room207-limo (fournie)
└── ros2_foxy/
    ├── room207.bash                raccourcis de room207-limo (fournis)
    ├── room207_limo/               environnement de référence (fourni)
    └── be_limo/                    NOS DÉVELOPPEMENTS
        ├── be_limo/                code des nœuds (Python)
        │   ├── localization_node.py      position du robot sur la carte
        │   ├── global_planner_node.py    planification (nœud)
        │   ├── roadmap.py                carte des voies, géométrie, A*
        │   ├── local_controller_node.py  contrôle (nœud) et machine à états
        │   ├── pure_pursuit.py           loi de commande
        │   ├── obstacle_detector_node.py détection d'obstacles (nœud)
        │   ├── obstacles.py              traitement du scan lidar
        │   ├── vision_node.py            détection caméra (nœud)
        │   ├── lane_vision.py            détection de la voie
        │   ├── sign_vision.py            détection des feux et panneaux stop
        │   ├── traffic_light_manager.py  feux de la simulation
        │   ├── frames.py, ros_utils.py   outils (repères, conversions)
        ├── launch/                 fichiers de lancement
        ├── config/                 paramètres (be_limo.yaml, amcl.yaml, slam.yaml)
        ├── worlds/                 monde Gazebo be_limo_track.world
        ├── rviz/                   configuration RViz
        ├── matlab/                 loi de commande et scénario en MATLAB
        ├── test/                   tests automatiques
        ├── doc/                    carte des nœuds
        └── README.md               détail des algorithmes, version MATLAB, robot réel
```

### 2.2. Architecture logicielle

Elle suit le découpage du Rendu 1 : procédé, perception, planification, contrôle.

```text
                 ┌───────────────────────────────────────────────────────────────┐
                 │ PROCÉDÉ : Gazebo (LIMO simulée) ou limo_base (robot réel)      │
                 └──┬──────────────┬───────────────────┬─────────────────────▲───┘
             /odom  │        /scan │    /rgb/image_raw │            /cmd_vel │ (Gazebo : via
                    ▼              ▼                   ▼                     │  gazebo_twist_adapter
          ┌──────────────────┐ ┌──────────────────┐ ┌──────────────┐         │  → /cmd_vel_gazebo)
          │ localization_node│ │ obstacle_detector│ │ vision_node  │         │
          └────────┬─────────┘ └────────┬─────────┘ └──────┬───────┘         │
       /robot_pose │  /obstacle_distance│  /detected_events │ /lane_detection │
                   ▼                    ▼                   ▼                 │
          ┌────────────────┐  /plan  ┌─────────────────────────────────────┐  │
          │ global_planner ├────────►│ local_controller                    ├──┘
          └───────▲────────┘         │ pure pursuit + machine à états      │
     /planner/goal│ /goal_pose       └──────────────▲──────────────────────┘
                  │                                 │ /supervisor/command
               (terminal ou RViz)            (terminal : start, pause, estop)
```

**Relations entre les fonctions**

1. `localization_node` donne la position du robot dans le repère de la piste (`/robot_pose`).
2. `global_planner` en déduit le nœud de départ, calcule l'itinéraire vers l'objectif et publie le chemin (`/plan`).
3. `local_controller` suit ce chemin et calcule `(v, ω)` à 20 Hz. Il ralentit ou s'arrête selon les détections :
   - la distance libre devant le robot (`obstacle_detector`) ;
   - les feux et les panneaux stop (`vision_node`).
4. À l'arrivée, il publie `GOAL_REACHED`. En mode boucle, `global_planner` relance alors le même itinéraire.

### 2.3. Nœuds ROS 2

| Nœud (exécutable) | Fonction | S'abonne à | Publie |
|---|---|---|---|
| `localization_node` | position du robot sur la carte | `/odom`, `/initialpose` | `/robot_pose`, TF `map → odom` |
| `global_planner` | plus court chemin (A*) sur le graphe des voies | `/robot_pose`, `/planner/goal`, `/goal_pose`, `/controller/state` | `/plan`, `/plan/route`, `/roadmap/markers` |
| `local_controller` | suivi du chemin (pure pursuit) et machine à états | `/plan`, `/robot_pose`, `/obstacle_distance`, `/detected_events`, `/lane_detection`, `/supervisor/command` | `/cmd_vel`, `/controller/state` |
| `obstacle_detector` | obstacles dans le couloir devant le robot | `/scan`, `/cmd_vel` | `/obstacle_distance`, `/obstacles`, `/obstacles/markers` |
| `vision_node` | voie, feux tricolores, panneaux stop | `/rgb/image_raw` | `/lane_detection`, `/detected_events`, `/vision/debug` |
| `traffic_light_manager` | allume les feux de la simulation | `/supervisor/traffic_lights` | `/traffic_lights/state` |

Nœuds externes lancés avec la simulation : `gzserver` (Gazebo), `robot_state_publisher`, `spawn_entity.py`, `gazebo_twist_adapter.py` (paquet `limo_car`), `rviz2`.

### 2.4. Topics

| Topic | Type | Contenu |
|---|---|---|
| `/odom` | `nav_msgs/Odometry` | odométrie (en simulation : position exacte dans le repère de la piste) |
| `/scan` | `sensor_msgs/LaserScan` | lidar |
| `/rgb/image_raw` | `sensor_msgs/Image` | caméra frontale |
| `/robot_pose` | `geometry_msgs/PoseStamped` | position du robot dans le repère `map` (piste centrée sur l'origine) |
| `/plan` | `nav_msgs/Path` | chemin à suivre, un point tous les 2 cm (QoS *transient local*) |
| `/plan/route` | `std_msgs/String` (JSON) | suite des nœuds et longueur : `{"route": [2, 4, 14, ...], "length": 17.6}` |
| `/planner/goal` | `std_msgs/String` | objectif : `"16"`, `"14,20,9"` ou `"demo"` (boucle) |
| `/goal_pose` | `geometry_msgs/PoseStamped` | objectif cliqué dans RViz (nœud le plus proche) |
| `/cmd_vel` | `geometry_msgs/Twist` | commande : `linear.x` = v (m/s), `angular.z` = ω (rad/s) |
| `/cmd_vel_gazebo` | `geometry_msgs/Twist` | commande convertie pour le plugin Gazebo (v, angle de braquage) |
| `/controller/state` | `std_msgs/String` (JSON) | état, vitesse, écart au chemin, progression |
| `/supervisor/command` | `std_msgs/String` | `start`, `pause`, `estop`, `reset`, ou `{"speed": 0.2}` |
| `/obstacle_distance` | `std_msgs/Float32` | distance libre devant le robot (m), `inf` si la voie est libre |
| `/obstacles` | `geometry_msgs/PoseArray` | obstacles dans le couloir (repère du robot) |
| `/lane_detection` | `std_msgs/Float32MultiArray` | `[valide, décalage du centre de la voie (m), angle de la voie (rad), confiance]` |
| `/detected_events` | `std_msgs/String` (JSON) | feux et panneaux vus : type, état (rouge/vert), distance, direction |
| `/vision/debug` | `sensor_msgs/Image` | image de la caméra avec les détections dessinées |
| `/supervisor/traffic_lights` | `std_msgs/String` | mode des feux : `auto`, `all_red`, `all_green`, `ew_green`, `ns_green` |
| `/traffic_lights/state` | `std_msgs/String` (JSON) | couleur de chaque feu |
| `/roadmap/markers`, `/obstacles/markers` | `visualization_msgs/MarkerArray` | affichage RViz |

### 2.5. Services

| Service | Type | Utilisé par |
|---|---|---|
| `/spawn_entity` | `gazebo_msgs/SpawnEntity` | `spawn_entity.py` (robot) ; `traffic_light_manager` (allumer un feu) |
| `/delete_entity` | `gazebo_msgs/DeleteEntity` | `traffic_light_manager` (éteindre un feu) ; retrait de l'obstacle pendant la démonstration |

### 2.6. Principaux paramètres (`ros2_foxy/be_limo/config/be_limo.yaml`)

| Nœud | Paramètre | Valeur | Rôle |
|---|---|---|---|
| `local_controller` | `speed` | 0,25 m/s | vitesse en ligne droite |
| | `lookahead_min`, `lookahead_gain` | 0,25 m ; 0,6 s | distance de visée `Ld = 0,25 + 0,6·v` |
| | `max_steering` | 0,41 rad | braquage maximal (23,6°) |
| | `obstacle_stop`, `obstacle_resume`, `obstacle_slow` | 0,35 ; 0,45 ; 0,80 m | arrêt, reprise, ralentissement devant un obstacle |
| | `red_light_min`, `red_light_distance` | 1,0 ; 1,4 m | distances auxquelles un feu rouge impose l'arrêt (depuis la ligne d'arrêt) |
| | `stop_sign_distance`, `stop_sign_duration` | 0,60 m ; 2,0 s | arrêt au panneau stop |
| | `confirm_frames` | 2 | images successives pour valider une détection |
| | `autostart` | `true` en simulation | démarrer sans attendre `start` |
| `obstacle_detector` | `half_width`, `max_range` | 0,16 m ; 1,5 m | demi-largeur et longueur du couloir surveillé |
| `vision_node` | `image_topic` | `/rgb/image_raw` | caméra |
| | `camera_height`, `camera_pitch`, `hfov` | 0,21 m ; 0 rad ; 60° | position et champ de la caméra (projection au sol) |
| `traffic_light_manager` | `period` | 12 s | durée d'une phase des feux |
| `global_planner` | `mission` | `demo` | itinéraire au démarrage |

### 2.7. Fichiers launch

| Fichier | Utilisation | Arguments |
|---|---|---|
| `sim_l2.launch.py` | **démonstration en simulation** : Gazebo, LIMO, nœuds `be_limo`, RViz | `mission` (`demo`), `start_node` (`2`), `autostart` (`true`), `gui` (`false`), `rviz` (`true`) |
| `real_l2.launch.py` | mêmes nœuds sur le robot réel, avec son driver | `initial_node`, `mission`, `use_camera`, `driver`, `speed`, `localization` (`odom` ou `lidar`), `map` |
| `mapping.launch.py` | carte lidar de la salle (robot réel, slam_toolbox) | `start_node`, `map` |

### 2.8. Algorithmes (résumé)

- **Planification** : la piste est un graphe orienté de 24 nœuds et 41 arcs (circulation à droite), repris de la carte des voies de la piste QCar. Chaque arc est une courbe droite – arc de cercle – droite, avec le rayon de la voie. L'itinéraire est le plus court chemin calculé par **A\***.
- **Contrôle** : **pure pursuit** sur le modèle bicyclette (empattement 0,24 m). Le robot vise un point du chemin à `Ld = 0,25 + 0,6·v`, braque de `δ = atan(2·L·sin α / Ld)` et envoie `ω = v·tan δ / L`. La vitesse est réduite en virage, et une **machine à états** gère les arrêts (arrêt d'urgence > obstacle > feu rouge > stop > ralentissement > en route).
- **Détection** :
  - **lidar** : les points du scan sont regroupés en amas, et seuls ceux situés dans le couloir que le robot va balayer comptent ;
  - **caméra** : masques de couleur HSV. La voie (ligne jaune, bord blanc) est projetée au sol. Un feu est un disque rouge ou vert dans un boîtier sombre, un stop un disque rouge bordé de blanc, et la distance vient de la taille apparente.

Le détail (équations, choix, limites) est dans [`ros2_foxy/be_limo/README.md`](ros2_foxy/be_limo/README.md).

---

## 3. Exemple de mise en œuvre

### 3.1. Lancer la démonstration

Terminal 1 :
```bash
source /opt/ros/foxy/setup.bash && source ~/ros2_ws/install/setup.bash
ros2 launch be_limo sim_l2.launch.py
```
Pour afficher aussi la fenêtre Gazebo : `ros2 launch be_limo sim_l2.launch.py gui:=true`. Sans carte graphique, elle peut être lente ; la simulation tourne de toute façon.

### 3.2. Résultat attendu

Après 20 à 40 s de chargement, RViz affiche la piste avec le graphe des voies (vert), les nœuds numérotés, le chemin planifié (bleu), le robot, les points du lidar et l'image de la caméra avec les détections. Le terminal affiche :
```text
[global_planner]: Itinéraire 2 -> 4 -> 14 -> 20 -> 22 -> 9 -> 0 -> 2 (17.6 m)
[local_controller]: Etat : NO_PLAN -> DRIVING
```
Le robot part du nœud 2 (voie du bas) et enchaîne, en un peu plus de 2 minutes :

| Étape | Lieu | Comportement attendu | Message dans le terminal 1 |
|---|---|---|---|
| 1 | voie de droite, vers le nœud 14 | arrêt de 2 s au panneau stop, avant le rond-point | `DRIVING -> STOP_SIGN`, puis `-> DRIVING` |
| 2 | voie du haut, entre les nœuds 20 et 22 | ralentit à moins de 0,8 m de l'obstacle orange, s'arrête à 0,35 m | `DRIVING -> SLOW_OBSTACLE -> STOP_OBSTACLE` |
| 3 | — | retirer l'obstacle (terminal 2, voir 3.3) : le robot repart | `STOP_OBSTACLE -> DRIVING` |
| 4 | carrefour central, nœud 9 | si le feu est rouge, arrêt à la ligne ; départ au vert (au plus 12 s) | `DRIVING -> STOP_RED_LIGHT`, puis `-> DRIVING` |
| 5 | retour au nœud 2 | arrivée, puis la boucle recommence | `DRIVING -> GOAL_REACHED` |

Sans action sur l'obstacle, le robot l'attend indéfiniment : il n'y a pas d'évitement.

### 3.3. Interagir avec la démonstration (terminal 2)

```bash
source /opt/ros/foxy/setup.bash && source ~/ros2_ws/install/setup.bash

# retirer l'obstacle
ros2 service call /delete_entity gazebo_msgs/srv/DeleteEntity "{name: obstacle_box}"

# forcer les feux : tous rouges, puis retour au cycle automatique
ros2 topic pub --once /supervisor/traffic_lights std_msgs/String "{data: all_red}"
ros2 topic pub --once /supervisor/traffic_lights std_msgs/String "{data: auto}"

# pause, reprise, arrêt d'urgence, réarmement
ros2 topic pub --once /supervisor/command std_msgs/String "{data: pause}"
ros2 topic pub --once /supervisor/command std_msgs/String "{data: start}"
ros2 topic pub --once /supervisor/command std_msgs/String "{data: estop}"
ros2 topic pub --once /supervisor/command std_msgs/String "{data: reset}"

# nouvel objectif : le nœud 16 (numéros sur la carte de be_limo/doc/carte_noeuds.png)
ros2 topic pub --once /planner/goal std_msgs/String "{data: '16'}"
```
Dans RViz, l'outil **2D Goal Pose** envoie aussi le robot vers le nœud le plus proche du clic.

### 3.4. Observer chaque fonction

| Fonction | Commande | Résultat attendu |
|---|---|---|
| Planification | `ros2 topic echo /plan/route --once` | `{"route": [2, 4, 14, 20, 22, 9, 0, 2], "length": 17.6, ...}` |
| Contrôle | `ros2 topic echo /controller/state` | `"state": "DRIVING"`, `"cross_track_error"` de quelques centimètres |
| Commande | `ros2 topic echo /cmd_vel` | `linear.x` jusqu'à 0,25 ; `angular.z` non nul dans les virages |
| Obstacles | `ros2 topic echo /obstacle_distance` | `inf`, puis la distance en approchant de l'obstacle |
| Voie | `ros2 topic echo /lane_detection` | `[1.0, ...]` sur les lignes droites, décalage de quelques centimètres |
| Feux et stop | `ros2 topic echo /detected_events` | `"type": "stop_sign"` vers le nœud 14, `"type": "traffic_light", "state": "red"` vers le nœud 9 |

Enregistrement d'un essai :
```bash
ros2 bag record /robot_pose /plan /cmd_vel /controller/state /obstacle_distance /detected_events -o essai_l2
```

### 3.5. Autres lancements

```bash
ros2 launch be_limo sim_l2.launch.py mission:=16                # du nœud 2 au nœud 16, puis arrêt
ros2 launch be_limo sim_l2.launch.py mission:=14,20,9           # passage par 14, 20, puis 9
ros2 launch be_limo sim_l2.launch.py start_node:=9 mission:=2   # départ du nœud 9
ros2 launch be_limo sim_l2.launch.py autostart:=false           # attendre la commande start
```

### 3.6. Version MATLAB de la loi de commande

Sans ROS, dans MATLAB :
```matlab
cd ros2_foxy/be_limo/matlab
simu_suivi        % suivi de la boucle : trajectoire, écart au chemin, vitesse
simu_scenario     % même boucle avec le stop, l'obstacle et le feu
```
Résultat attendu : une figure avec la trajectoire superposée au chemin, et dans la fenêtre de commande la durée du tour, l'écart moyen et maximal (quelques centimètres), puis la durée de chaque arrêt.

### 3.7. Tests automatiques

```bash
cd ~/ros2_ws/src/be-2026-group-01/ros2_foxy/be_limo
python3 -m pytest -q test/
```
Résultat attendu : `9 passed`. Les tests vérifient :
- la carte des voies et l'A* ;
- le suivi de trajectoire ;
- les détecteurs ;
- un parcours complet des nœuds en boucle fermée.

Ils tournent sans Gazebo.

---

## 4. Pour aller plus loin

Le README du paquet ([`ros2_foxy/be_limo/README.md`](ros2_foxy/be_limo/README.md)) détaille :
- les algorithmes ;
- la version MATLAB ;
- les tests ;
- l'utilisation sur le robot réel (`real_l2.launch.py`, localisation lidar par AMCL) ;
- les limites connues.

L'environnement de référence `room207-limo` (simulation de la salle 207, raccourcis `r207_*`, version Simulink) est documenté dans son dépôt d'origine, `robotic_lab/room207-limo`.
