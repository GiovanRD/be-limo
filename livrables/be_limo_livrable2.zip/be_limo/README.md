# be_limo — Livrable 2 (L2.1–L3.1)

**Simulation de planification, de contrôle et de détection** — BE Véhicule Autonome, ENSEM, groupe 1
(Crystal RIBU, Morgan HOFFMANN, Giovan ROCCA-DURINGER). Paquet ROS 2 Foxy, robot AgileX LIMO n° 201.

---

## 1. Contenu

Le robot part du nœud 2 et parcourt la **boucle de démonstration** `2 → 4 → 14 → 20 → 22 → 9 → 0 → 2` (17,6 m). En chemin, il :

1. **s'arrête 2 s au panneau stop**, avant le rond-point ;
2. **ralentit puis s'arrête devant l'obstacle** sur la voie du haut, et repart quand la voie est libre ;
3. **s'arrête au feu rouge** du carrefour central, et repart au vert.

![Carte des nœuds](doc/carte_noeuds.png)

*En bleu : la boucle de démonstration. En rouge : les 24 nœuds de la carte (le numéro sert à donner un objectif). Carrés : feux, stop, obstacle.*

### Architecture

```text
PROCÉDÉ        Gazebo ou limo_base ──► /odom  /scan  /rgb/image_raw
PERCEPTION     localization_node   ──► /robot_pose
               obstacle_detector   ──► /obstacle_distance  /obstacles
               vision_node         ──► /lane_detection  /detected_events  /vision/debug
PLANIFICATION  global_planner      ──► /plan  /plan/route        (objectif : /planner/goal, /goal_pose)
CONTRÔLE       local_controller    ──► /cmd_vel  /controller/state  (commandes : /supervisor/command)
SIMULATION     traffic_light_manager (allume les feux dans Gazebo)
               gazebo_twist_adapter  (/cmd_vel → /cmd_vel_gazebo, paquet limo_car)
```

| Nœud | Rôle | Fichier |
|---|---|---|
| `localization_node` | Position du robot sur la carte de la piste | `be_limo/localization_node.py` |
| `global_planner` | Plus court chemin (A*) sur le graphe des voies | `be_limo/global_planner_node.py`, `be_limo/roadmap.py` |
| `local_controller` | Suivi de trajectoire (pure pursuit) et machine à états (stop, feu, obstacle) | `be_limo/local_controller_node.py`, `be_limo/pure_pursuit.py` |
| `obstacle_detector` | Obstacles dans le couloir devant le robot (lidar) | `be_limo/obstacle_detector_node.py`, `be_limo/obstacles.py` |
| `vision_node` | Voie, feux, panneaux stop (caméra) | `be_limo/vision_node.py`, `be_limo/lane_vision.py`, `be_limo/sign_vision.py` |
| `traffic_light_manager` | Feux du carrefour dans Gazebo (simulation seulement) | `be_limo/traffic_light_manager.py` |

Les réglages sont dans `config/be_limo.yaml`. Le monde Gazebo est `worlds/be_limo_track.world` : la piste QCar, quatre feux au carrefour central, un panneau stop et un obstacle.

---

## 2. Compilation

Le paquet se trouve dans `ros2_foxy/be_limo` du dépôt du groupe. Il utilise les dépôts communs du labo, installés dans le même workspace selon leurs guides : `limo` (`limo_car`, `limo_description`), `environment` (`qcar_large_track`), et `gazebo_ros`.

```bash
cd ~/ros2_ws
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install --packages-select be_limo
source install/setup.bash
ros2 pkg executables be_limo
```
Résultat attendu : 6 exécutables (`global_planner`, `local_controller`, `localization_node`, `obstacle_detector`, `traffic_light_manager`, `vision_node`).

---

## 3. Simulation

```bash
ros2 launch be_limo sim_l2.launch.py
```
Gazebo démarre sans fenêtre (`gui:=true` pour l'afficher), RViz s'ouvre avec la carte, le chemin planifié, le robot, le lidar et l'image de la caméra avec ses détections. Le robot démarre seul la boucle de démonstration.

| Argument | Défaut | Rôle |
|---|---|---|
| `mission` | `demo` | `demo` (boucle), un nœud (`16`) ou une liste (`14,20,9`) |
| `start_node` | `2` | nœud de départ du robot |
| `autostart` | `true` | `false` : attendre la commande `start` |
| `gui` | `false` | fenêtre Gazebo |
| `rviz` | `true` | RViz |

### Commandes pendant la simulation (autre terminal)

| Action | Commande |
|---|---|
| Démarrer / pause / arrêt d'urgence / réarmer | `ros2 topic pub --once /supervisor/command std_msgs/String "{data: start}"` (ou `pause`, `estop`, `reset`) |
| Nouvel objectif | `ros2 topic pub --once /planner/goal std_msgs/String "{data: '16'}"` (ou `'14,20,9'`, `demo`) |
| Retirer l'obstacle | `ros2 service call /delete_entity gazebo_msgs/srv/DeleteEntity "{name: obstacle_box}"` |
| Feux | `ros2 topic pub --once /supervisor/traffic_lights std_msgs/String "{data: all_red}"` (ou `auto`, `ew_green`, `ns_green`, `all_green`) |

Dans RViz, l'outil **2D Goal Pose** envoie aussi le robot vers le nœud le plus proche du clic.

### Observer chaque fonction

| Fonction | Commande | Résultat attendu |
|---|---|---|
| Planification | `ros2 topic echo /plan/route --once` | `{"route": [2, 4, 14, 20, 22, 9, 0, 2], "length": 17.6, ...}` |
| Contrôle | `ros2 topic echo /controller/state` | état (`DRIVING`, `STOP_SIGN`...), écart à la trajectoire |
| Obstacles | `ros2 topic echo /obstacle_distance` | `inf` quand la voie est libre, ~0,35 m devant l'obstacle |
| Voie | `ros2 topic echo /lane_detection` | `[valide, décalage (m), cap (rad), confiance]` |
| Feux et stop | `ros2 topic echo /detected_events` | `"type": "traffic_light", "state": "red", "distance": ...` |

---

## 4. Fonctionnement

### Planification — `roadmap.py`, `global_planner_node.py`
- La piste est un **graphe orienté** de 24 nœuds (entrées et sorties des carrefours, circulation à droite) et 41 arcs, repris de la carte routière Quanser de la piste et convertis dans le repère Gazebo (piste de 4,88 × 6,20 m centrée sur l'origine).
- Chaque arc est une courbe **droite – arc de cercle – droite**, avec le rayon de la voie (0,62 m voie intérieure, 0,89 m voie extérieure, 0,68 m rond-point).
- Le plus court chemin est calculé par **A\*** (heuristique : distance à vol d'oiseau). Le départ est le nœud le plus proche devant le robot et orienté comme lui.

### Contrôle — `pure_pursuit.py`, `local_controller_node.py`
- **Pure pursuit** sur le modèle bicyclette (empattement L = 0,24 m), écrit à l'essieu arrière : le robot vise un point du chemin à la distance `Ld = 0,25 + 0,6·v` et braque de `δ = atan(2·L·sin α / Ld)`. La commande publiée est `v` et `ω = v·tan δ / L` sur `/cmd_vel`, comme pour le robot réel.
- Vitesse de 0,25 m/s, réduite dans les virages (`v = v0 / (1 + 1,5·|κ|)`) et à l'approche du but. Braquage limité à 23,6°.
- Le chemin se recoupe aux carrefours : le point le plus proche est cherché seulement **vers l'avant** (fenêtre de 60 points).
- **Machine à états**, par priorité : arrêt d'urgence > pause > pas de chemin ou de position > obstacle (arrêt sous 0,35 m, reprise au-delà de 0,45 m) > feu rouge > stop (2 s, puis panneau ignoré 6 s) > ralentissement (obstacle sous 0,8 m) > en route. Une détection doit être vue sur 2 images de suite.

### Détection — `obstacles.py`, `lane_vision.py`, `sign_vision.py`
- **Obstacles (lidar)** : les points du scan sont regroupés en amas. Un obstacle compte s'il est dans le **couloir** que le robot va balayer : un arc de la courbure actuelle (`ω/v`), de 2 × 0,16 m de large et 1,5 m de long.
- **Voie (caméra)** : masques HSV de la ligne jaune et du bord blanc, projection des points au sol (modèle sténopé, hauteur et inclinaison de la caméra connues), droite ajustée par côté. Sortie : décalage du centre de la voie à 0,7 m devant le robot et angle de la voie.
- **Feux et stop (caméra)** : taches rouges ou vertes saturées au-dessus de l'horizon. Un disque dans un boîtier sombre est un **feu**, un disque rouge bordé de blanc est un **stop**. La distance vient de la taille apparente (`d = f·D / diamètre`). Les feux sont placés de l'autre côté du carrefour : le rouge n'est respecté que s'il est vu entre 1,0 et 1,4 m, c'est-à-dire depuis la ligne d'arrêt.

## 5. Version MATLAB (dossier `matlab/`)

La loi de commande et le scénario existent aussi en MATLAB, sans ROS, pour étudier le contrôleur seul. Les fichiers sont courts et utilisent les mêmes paramètres que `config/be_limo.yaml`.

| Fichier | Rôle |
|---|---|
| `parametres_limo.m` | paramètres du robot (empattement, butée de direction) et du contrôleur |
| `modele_limo.m` | modèle cinématique bicyclette : `x' = v cos θ`, `y' = v sin θ`, `θ' = v tan δ / L` |
| `pure_pursuit.m` | loi de commande : point visé à `Ld = 0,25 + 0,6·v`, `δ = atan(2·L·sin α / Ld)`, vitesse réduite en virage |
| `simu_suivi.m` | suivi de la boucle de démonstration : trajectoire, écart au chemin, vitesse |
| `simu_scenario.m` | même boucle avec le panneau stop, l'obstacle et le feu (rouge 12 s, vert 12 s) |
| `chemin_demo.txt`, `noeuds.txt` | chemin de la boucle (un point tous les 2 cm) et nœuds de la carte, exportés de `roadmap.py` |

Utilisation, dans MATLAB :
```matlab
cd ros2_foxy/be_limo/matlab
simu_suivi       % affiche la durée du tour et l'écart moyen et maximal au chemin
simu_scenario    % affiche la durée et le début de chaque arrêt
```
Pour essayer un autre réglage, modifier `parametres_limo.m` (par exemple `k_Ld` ou `v_nominale`) et relancer.

Pour exporter un autre itinéraire :
```bash
cd ros2_foxy/be_limo
python3 -c "from be_limo.roadmap import RoadMap; r = RoadMap(); _, pts = r.plan([2, 16]); open('matlab/chemin.txt', 'w').write(''.join('%.4f %.4f\n' % p for p in pts))"
```

---

## 6. Robot réel

```bash
# sur la LIMO, robot posé au nœud 2, dans l'axe de la voie
ros2 launch be_limo real_l2.launch.py initial_node:=2 mission:=demo use_camera:=true
# autre terminal : démarrer, puis arrêter
timeout 10 ros2 topic pub -r 2 /supervisor/command std_msgs/String "{data: start}"
timeout 10 ros2 topic pub -r 2 /supervisor/command std_msgs/String "{data: estop}"
```
`real_l2.launch.py` lance aussi le driver (`limo_start`) ; `driver:=false` si celui-ci tourne déjà. Vitesse par défaut : 0,15 m/s.

La position vient de l'odométrie, initialisée au nœud de départ. Une **localisation lidar** est aussi fournie : carte de la salle avec `mapping.launch.py` (slam_toolbox), puis `real_l2.launch.py localization:=lidar map:=~/maps/salle207.yaml` (AMCL).

**État au 16/11/2026** :

| Fonction | Simulation | Robot réel (LIMO 201) |
|---|---|---|
| Driver, lidar, caméra | OK | OK |
| Arrêt devant un obstacle (lidar) | OK | OK : le robot ne heurte pas les murs |
| Analyse de l'environnement (voie, feux, stop) | OK | voie détectée sur les images, pas encore exploitée dans la conduite |
| Suivi d'un itinéraire d'un point à un autre | OK (écart < 4 cm) | pas encore atteint : réglage en cours |
| Localisation lidar | — | écrite, pas encore essayée |

---

## 7. Tests

```bash
cd ros2_foxy/be_limo
python3 -m pytest -q test/
```
Sans ROS ni Gazebo (Python 3, numpy, OpenCV, pytest). Les tests qui utilisent la texture de la piste la cherchent dans le dépôt `environment` du workspace, et sont ignorés s'il est absent.

| Test | Vérification |
|---|---|
| `test_every_edge_stays_on_the_road` | les 41 arcs restent sur la chaussée (texture de la piste) |
| `test_routes`, `test_every_node_reachable` | A* ; chaque nœud est atteignable depuis chaque nœud |
| `test_pure_pursuit_follows_the_demo_loop` | boucle complète en simulation cinématique, écart < 6 cm |
| `test_corridor_geometry`, `test_obstacle_in_front_and_beside` | couloir du lidar, en ligne droite et en virage |
| `test_lane_offset_and_signs` | décalage de voie à ±1,5 cm, feu rouge, feu vert, stop |
| `test_room_map_calibration` | lien carte de la salle ↔ carte de la piste |
| `test_demo_loop` | les nœuds ROS 2 en boucle fermée autour d'un robot simulé (lidar et caméra synthétiques) : stop, obstacle, feu rouge, arrivée |

`test/offline_sim.py` rejoue le scénario complet sans Gazebo. Sur la boucle de démonstration : 17,6 m en 139 s, écart latéral moyen 1,1 cm (maximum 3,9 cm).

---

## 8. Limites

- Pas d'évitement : le robot attend que la voie se libère.
- La détection de voie est précise en ligne droite (±1,5 cm), approximative dans les virages serrés.
- Le panneau stop simulé est un disque rouge bordé de blanc, pas un octogone.
- Les seuils de couleur des détecteurs (`lane_vision.py`, `sign_vision.py`) sont à ajuster sur les images de Gazebo et de la caméra réelle.
